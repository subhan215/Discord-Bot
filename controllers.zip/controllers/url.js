const URL = require("../models/url");

async function handleUrl(req , res) {
    const shortId = req.params.shortId ; 
    console.log(shortId)
    const url = await URL.findOne({shortId})
    console.log(url.redirectURL)
    return res.redirect(url.redirectURL)
}
module.exports = {
    handleUrl
}