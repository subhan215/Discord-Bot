const express = require("express")
const {handleUrl} = require("../controllers/url")
const router = express.Router() ;

router.get("/:shortId" , handleUrl)
const urlRoute = router
module.exports = urlRoute